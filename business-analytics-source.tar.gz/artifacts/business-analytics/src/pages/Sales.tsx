import { useState } from "react";
import { Download, Upload, Plus, Pencil, Trash2, RefreshCw } from "lucide-react";
import { LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import Layout from "@/components/Layout";
import StatCard from "@/components/StatCard";
import { formatINR } from "@/lib/format";
import {
  useGetSalesStats, useGetSalesTrend, useGetSalesByCategory,
  useGetSalesTopProducts, useGetSales, useDeleteSale,
  getGetSalesQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";

const COLORS = ["#4F46E5", "#10B981", "#F59E0B", "#EF4444", "#8B5CF6"];

function CategoryBadge({ cat }: { cat: string }) {
  const map: Record<string, string> = {
    Electronics: "bg-blue-100 text-blue-700",
    Accessories: "bg-amber-100 text-amber-700",
    Wearables: "bg-purple-100 text-purple-700",
    "Home Appliances": "bg-orange-100 text-orange-700",
  };
  return <span className={`px-2 py-0.5 rounded-full text-[11px] font-medium ${map[cat] ?? "bg-gray-100 text-gray-600"}`}>{cat}</span>;
}

export default function Sales() {
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("");
  const [channel, setChannel] = useState("");
  const queryClient = useQueryClient();

  const { data: statsData } = useGetSalesStats();
  const { data: trend } = useGetSalesTrend({ period: "daily" });
  const { data: byCategory } = useGetSalesByCategory();
  const { data: topProducts } = useGetSalesTopProducts();
  const { data: sales } = useGetSales({ page, limit: 10, search: search || undefined, category: category || undefined, channel: channel || undefined });
  const deleteMutation = useDeleteSale({
    mutation: {
      onSuccess: () => queryClient.invalidateQueries({ queryKey: getGetSalesQueryKey() }),
    },
  });

  return (
    <Layout>
      <div className="p-6 space-y-5">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold text-gray-900">Sales Overview</h1>
            <p className="text-gray-500 text-sm">Track and analyze your sales performance</p>
          </div>
          <div className="flex items-center gap-2">
            <button className="flex items-center gap-2 border border-gray-200 bg-white text-gray-700 text-sm px-3 py-2 rounded-lg hover:bg-gray-50 transition-colors">
              <Download className="w-4 h-4" /> Export
            </button>
            <button className="flex items-center gap-2 border border-gray-200 bg-white text-gray-700 text-sm px-3 py-2 rounded-lg hover:bg-gray-50 transition-colors">
              <Upload className="w-4 h-4" /> Upload CSV
            </button>
            <button className="flex items-center gap-2 bg-blue-600 text-white text-sm px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors font-medium">
              <Plus className="w-4 h-4" /> Add New Sale
            </button>
          </div>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-xl border border-gray-200 p-4 shadow-sm">
          <div className="flex items-center gap-4 flex-wrap">
            <input type="search" placeholder="Search Product / Invoice / Customer" value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="flex-1 min-w-48 px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" />
            <select value={category} onChange={(e) => setCategory(e.target.value)}
              className="px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white">
              <option value="">All Categories</option>
              {["Electronics", "Accessories", "Wearables", "Home Appliances"].map((c) => <option key={c}>{c}</option>)}
            </select>
            <select value={channel} onChange={(e) => setChannel(e.target.value)}
              className="px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white">
              <option value="">All Channels</option>
              {["Online", "Retail"].map((c) => <option key={c}>{c}</option>)}
            </select>
            <button className="bg-blue-600 text-white text-sm px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors">Apply Filters</button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-4 gap-4">
          <StatCard title="Total Revenue" value={formatINR(statsData?.totalRevenue ?? 250400)} change={statsData?.revenueChange ?? 18.6}
            icon={<span className="text-emerald-600 font-bold text-sm">₹</span>} iconBg="bg-emerald-100" />
          <StatCard title="Total Units Sold" value={(statsData?.totalUnitsSold ?? 840).toLocaleString("en-IN")} change={statsData?.unitsSoldChange ?? 12.4}
            icon={<span className="text-blue-600 font-bold text-sm">U</span>} iconBg="bg-blue-100" />
          <StatCard title="Total Transactions" value={(statsData?.totalTransactions ?? 215).toLocaleString("en-IN")} change={statsData?.transactionsChange ?? 15.3}
            icon={<span className="text-purple-600 font-bold text-sm">T</span>} iconBg="bg-purple-100" />
          <StatCard title="New Customers" value={(statsData?.newCustomers ?? 31).toLocaleString("en-IN")} change={statsData?.newCustomersChange ?? 24.0}
            icon={<span className="text-orange-600 font-bold text-sm">C</span>} iconBg="bg-orange-100" />
        </div>

        {/* Charts + Right Panel */}
        <div className="grid grid-cols-12 gap-4">
          <div className="col-span-4 bg-white rounded-xl border border-gray-200 p-4 shadow-sm">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-semibold text-gray-800">Sales Trend</h3>
              <select className="text-xs border border-gray-200 rounded px-2 py-1 bg-white text-gray-600"><option>Daily</option></select>
            </div>
            <ResponsiveContainer width="100%" height={180}>
              <LineChart data={trend ?? []}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="label" tick={{ fontSize: 9 }} tickFormatter={(v) => v.slice(4)} />
                <YAxis tick={{ fontSize: 9 }} tickFormatter={(v) => `${(v / 1000).toFixed(0)}k`} />
                <Tooltip formatter={(v: number) => formatINR(v)} />
                <Line type="monotone" dataKey="value" stroke="#2563EB" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="col-span-4 bg-white rounded-xl border border-gray-200 p-4 shadow-sm">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-semibold text-gray-800">Sales by Product Category</h3>
            </div>
            <div className="flex items-center gap-3">
              <ResponsiveContainer width={120} height={120}>
                <PieChart>
                  <Pie data={byCategory ?? []} dataKey="value" cx="50%" cy="50%" innerRadius={30} outerRadius={55}>
                    {(byCategory ?? []).map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
              <div className="flex-1 space-y-1">
                {(byCategory ?? []).map((cat, i) => (
                  <div key={cat.name} className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-1.5">
                      <div className="w-2 h-2 rounded-full" style={{ background: COLORS[i % COLORS.length] }}></div>
                      <span className="text-gray-600">{cat.name}</span>
                    </div>
                    <span className="text-gray-400">{cat.percentage}%</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="col-span-4 bg-white rounded-xl border border-gray-200 p-4 shadow-sm">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-semibold text-gray-800">Top Selling Products</h3>
              <button className="text-blue-600 text-xs hover:underline">View All</button>
            </div>
            <div className="space-y-2.5">
              {(topProducts ?? []).map((p, i) => (
                <div key={p.id} className="flex items-center gap-2 text-xs">
                  <span className="w-5 h-5 bg-gray-100 rounded-full flex items-center justify-center text-gray-500 font-bold">{i + 1}</span>
                  <div className="flex-1">
                    <p className="font-medium text-gray-800">{p.name}</p>
                    <p className="text-gray-400">{p.unitsSold} units</p>
                  </div>
                  <span className="font-semibold text-gray-800">{formatINR(p.revenue)}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Sales Records Table */}
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm">
          <div className="flex items-center justify-between p-4 border-b border-gray-100">
            <h3 className="font-semibold text-gray-800">Sales Records</h3>
            <div className="flex gap-2">
              <button className="p-1.5 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded transition-colors"><RefreshCw className="w-4 h-4" /></button>
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead className="bg-gray-50 border-b border-gray-100">
                <tr>
                  {["Invoice ID", "Date", "Customer", "Product", "Category", "Qty", "Unit Price", "Revenue", "Channel", "Actions"].map((h) => (
                    <th key={h} className="text-left px-4 py-3 font-medium text-gray-500">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {(sales?.data ?? []).map((s) => (
                  <tr key={s.id} className="hover:bg-gray-50 transition-colors" data-testid={`sale-${s.id}`}>
                    <td className="px-4 py-3 text-blue-600 font-medium">{s.invoiceId}</td>
                    <td className="px-4 py-3 text-gray-600">{s.date}</td>
                    <td className="px-4 py-3 text-gray-800">{s.customer}</td>
                    <td className="px-4 py-3 text-gray-800">{s.product}</td>
                    <td className="px-4 py-3"><CategoryBadge cat={s.category} /></td>
                    <td className="px-4 py-3 text-gray-600">{s.qty}</td>
                    <td className="px-4 py-3 text-gray-600">{formatINR(s.unitPrice)}</td>
                    <td className="px-4 py-3 font-semibold text-gray-800">{formatINR(s.revenue)}</td>
                    <td className="px-4 py-3 text-gray-600">{s.channel}</td>
                    <td className="px-4 py-3">
                      <div className="flex gap-1.5">
                        <button className="p-1 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded transition-colors"><Pencil className="w-3.5 h-3.5" /></button>
                        <button onClick={() => deleteMutation.mutate({ id: s.id })}
                          className="p-1 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded transition-colors"><Trash2 className="w-3.5 h-3.5" /></button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="flex items-center justify-between px-4 py-3 border-t border-gray-100">
            <span className="text-xs text-gray-500">Showing {(page - 1) * 10 + 1} to {Math.min(page * 10, sales?.total ?? 0)} of {sales?.total ?? 0} entries</span>
            <div className="flex gap-1">
              {[1, 2, 3, 4, 5].map((p) => (
                <button key={p} onClick={() => setPage(p)}
                  className={`w-7 h-7 text-xs rounded ${page === p ? "bg-blue-600 text-white" : "text-gray-500 hover:bg-gray-100"}`}>{p}</button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
