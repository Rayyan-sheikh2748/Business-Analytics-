import { useState } from "react";
import { Download, Upload, Plus, Pencil, Trash2, RefreshCw, AlertTriangle, Package } from "lucide-react";
import { LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import Layout from "@/components/Layout";
import StatCard from "@/components/StatCard";
import { formatINR } from "@/lib/format";
import {
  useGetInventoryStats, useGetInventory, useGetInventoryStockStatus,
  useGetInventoryLowStockAlerts, useGetInventoryRecentMovements,
  useGetInventoryTrend, useGetInventoryByCategory,
  useDeleteInventoryItem, getGetInventoryQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";

const COLORS = ["#10B981", "#F59E0B", "#EF4444", "#94A3B8"];

function StockBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    "In Stock": "bg-emerald-100 text-emerald-700",
    "Low Stock": "bg-amber-100 text-amber-700",
    "Out of Stock": "bg-red-100 text-red-700",
  };
  return <span className={`px-2 py-0.5 rounded-full text-[11px] font-medium ${map[status] ?? "bg-gray-100 text-gray-600"}`}>{status}</span>;
}

function CategoryBadge({ cat }: { cat: string }) {
  const map: Record<string, string> = {
    Electronics: "bg-blue-100 text-blue-700",
    Accessories: "bg-amber-100 text-amber-700",
    Wearables: "bg-purple-100 text-purple-700",
    "Home Appliances": "bg-orange-100 text-orange-700",
  };
  return <span className={`px-2 py-0.5 rounded-full text-[11px] font-medium ${map[cat] ?? "bg-gray-100 text-gray-600"}`}>{cat}</span>;
}

export default function Inventory() {
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("");
  const [warehouse, setWarehouse] = useState("");
  const queryClient = useQueryClient();

  const { data: stats } = useGetInventoryStats();
  const { data: inventory } = useGetInventory({ page, limit: 10, search: search || undefined, category: category || undefined, warehouse: warehouse || undefined });
  const { data: stockStatus } = useGetInventoryStockStatus();
  const { data: lowStock } = useGetInventoryLowStockAlerts();
  const { data: movements } = useGetInventoryRecentMovements();
  const { data: trend } = useGetInventoryTrend();
  const { data: byCategory } = useGetInventoryByCategory();
  const deleteMutation = useDeleteInventoryItem({
    mutation: { onSuccess: () => queryClient.invalidateQueries({ queryKey: getGetInventoryQueryKey() }) },
  });

  return (
    <Layout>
      <div className="p-6 space-y-5">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold text-gray-900">Inventory Overview</h1>
            <p className="text-gray-500 text-sm">Track stock levels, manage inventory and get alerts</p>
          </div>
          <div className="flex items-center gap-2">
            <button className="flex items-center gap-2 border border-gray-200 bg-white text-gray-700 text-sm px-3 py-2 rounded-lg hover:bg-gray-50">
              <Download className="w-4 h-4" /> Export
            </button>
            <button className="flex items-center gap-2 border border-gray-200 bg-white text-gray-700 text-sm px-3 py-2 rounded-lg hover:bg-gray-50">
              <Upload className="w-4 h-4" /> Import CSV
            </button>
            <button className="flex items-center gap-2 bg-blue-600 text-white text-sm px-4 py-2 rounded-lg hover:bg-blue-700 font-medium">
              <Plus className="w-4 h-4" /> Add New Product
            </button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-5 gap-4">
          <StatCard title="Total Products" value={(stats?.totalProducts ?? 128).toLocaleString("en-IN")}
            icon={<Package className="w-5 h-5 text-blue-600" />} iconBg="bg-blue-100" />
          <StatCard title="Total Stock (Units)" value={(stats?.totalStock ?? 12458).toLocaleString("en-IN")}
            icon={<span className="text-emerald-600 font-bold text-sm">S</span>} iconBg="bg-emerald-100" />
          <StatCard title="Low Stock Items" value={(stats?.lowStockItems ?? 18).toString()}
            icon={<AlertTriangle className="w-5 h-5 text-amber-500" />} iconBg="bg-amber-100" />
          <StatCard title="Out of Stock" value={(stats?.outOfStockItems ?? 6).toString()}
            icon={<span className="text-red-500 font-bold text-sm">!</span>} iconBg="bg-red-100" />
          <StatCard title="Inventory Value" value={formatINR(stats?.inventoryValue ?? 2475350)}
            icon={<span className="text-purple-600 font-bold text-sm">₹</span>} iconBg="bg-purple-100" />
        </div>

        {/* Filters */}
        <div className="bg-white rounded-xl border border-gray-200 p-4 shadow-sm">
          <div className="flex items-center gap-3 flex-wrap">
            <input type="search" placeholder="Search Product / SKU" value={search} onChange={(e) => setSearch(e.target.value)}
              className="flex-1 min-w-48 px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" />
            <select value={category} onChange={(e) => setCategory(e.target.value)}
              className="px-3 py-2 text-sm border border-gray-200 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-blue-500">
              <option value="">All Categories</option>
              {["Electronics", "Accessories", "Wearables", "Home Appliances"].map((c) => <option key={c}>{c}</option>)}
            </select>
            <select value={warehouse} onChange={(e) => setWarehouse(e.target.value)}
              className="px-3 py-2 text-sm border border-gray-200 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-blue-500">
              <option value="">All Warehouses</option>
              {["Main Warehouse", "East Warehouse", "West Warehouse"].map((w) => <option key={w}>{w}</option>)}
            </select>
            <button className="bg-blue-600 text-white text-sm px-4 py-2 rounded-lg hover:bg-blue-700">Apply Filters</button>
          </div>
        </div>

        <div className="grid grid-cols-12 gap-4">
          {/* Inventory Table */}
          <div className="col-span-8 bg-white rounded-xl border border-gray-200 shadow-sm">
            <div className="flex items-center justify-between p-4 border-b border-gray-100">
              <h3 className="font-semibold text-gray-800">Inventory List</h3>
              <button className="p-1.5 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded"><RefreshCw className="w-4 h-4" /></button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead className="bg-gray-50 border-b border-gray-100">
                  <tr>
                    {["Product", "SKU", "Category", "Warehouse", "Stock", "Threshold", "Status", "Stock Value", "Actions"].map((h) => (
                      <th key={h} className="text-left px-4 py-3 font-medium text-gray-500">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-50">
                  {(inventory?.data ?? []).map((item) => (
                    <tr key={item.id} className="hover:bg-gray-50" data-testid={`product-${item.id}`}>
                      <td className="px-4 py-3 font-medium text-gray-800">{item.product}</td>
                      <td className="px-4 py-3 text-gray-500">{item.sku}</td>
                      <td className="px-4 py-3"><CategoryBadge cat={item.category} /></td>
                      <td className="px-4 py-3 text-gray-600">{item.warehouse}</td>
                      <td className={`px-4 py-3 font-semibold ${item.stock === 0 ? "text-red-500" : item.stock <= item.threshold ? "text-amber-500" : "text-emerald-600"}`}>{item.stock}</td>
                      <td className="px-4 py-3 text-gray-500">{item.threshold}</td>
                      <td className="px-4 py-3"><StockBadge status={item.status} /></td>
                      <td className="px-4 py-3 font-medium text-gray-800">{formatINR(item.stockValue)}</td>
                      <td className="px-4 py-3">
                        <div className="flex gap-1.5">
                          <button className="p-1 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded"><Pencil className="w-3.5 h-3.5" /></button>
                          <button onClick={() => deleteMutation.mutate({ id: item.id })}
                            className="p-1 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded"><Trash2 className="w-3.5 h-3.5" /></button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="flex items-center justify-between px-4 py-3 border-t border-gray-100">
              <span className="text-xs text-gray-500">Showing {(page - 1) * 10 + 1} to {Math.min(page * 10, inventory?.total ?? 0)} of {inventory?.total ?? 0} entries</span>
              <div className="flex gap-1">
                {[1, 2, 3].map((p) => (
                  <button key={p} onClick={() => setPage(p)}
                    className={`w-7 h-7 text-xs rounded ${page === p ? "bg-blue-600 text-white" : "text-gray-500 hover:bg-gray-100"}`}>{p}</button>
                ))}
              </div>
            </div>
          </div>

          {/* Right Panel */}
          <div className="col-span-4 space-y-4">
            <div className="bg-white rounded-xl border border-gray-200 p-4 shadow-sm">
              <h3 className="font-semibold text-gray-800 mb-3">Stock Status Summary</h3>
              <div className="flex items-center gap-3">
                <ResponsiveContainer width={100} height={100}>
                  <PieChart>
                    <Pie data={stockStatus ?? []} dataKey="count" cx="50%" cy="50%" innerRadius={25} outerRadius={45}>
                      {(stockStatus ?? []).map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>
                <div className="flex-1 space-y-1.5">
                  {(stockStatus ?? []).map((s, i) => (
                    <div key={s.status} className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-1.5">
                        <div className="w-2 h-2 rounded-full" style={{ background: COLORS[i % COLORS.length] }}></div>
                        <span className="text-gray-600">{s.status}</span>
                      </div>
                      <span className="text-gray-500">{s.count} ({s.percentage}%)</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl border border-gray-200 p-4 shadow-sm">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold text-gray-800">Low Stock Alerts</h3>
                <button className="text-blue-600 text-xs hover:underline">View All</button>
              </div>
              <div className="space-y-2">
                {(lowStock ?? []).map((item) => (
                  <div key={item.id} className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 bg-amber-100 rounded flex items-center justify-center">
                        <AlertTriangle className="w-3 h-3 text-amber-600" />
                      </div>
                      <span className="text-gray-700">{item.product}</span>
                    </div>
                    <span className="text-amber-600 font-medium">{item.stock} units left</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-xl border border-gray-200 p-4 shadow-sm">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold text-gray-800">Recent Stock Movements</h3>
              </div>
              <div className="space-y-2">
                {(movements ?? []).map((m) => (
                  <div key={m.id} className="flex items-center justify-between text-xs">
                    <div>
                      <p className="font-medium text-gray-800">{m.product}</p>
                      <p className="text-gray-400">{m.warehouse} · {m.date}</p>
                    </div>
                    <span className={`font-semibold ${m.change > 0 ? "text-emerald-600" : "text-red-500"}`}>
                      {m.change > 0 ? "+" : ""}{m.change}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Charts */}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white rounded-xl border border-gray-200 p-4 shadow-sm">
            <h3 className="font-semibold text-gray-800 mb-3">Stock Trend</h3>
            <ResponsiveContainer width="100%" height={160}>
              <LineChart data={trend ?? []}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="label" tick={{ fontSize: 9 }} />
                <YAxis tick={{ fontSize: 9 }} tickFormatter={(v) => `${(v / 1000).toFixed(0)}k`} />
                <Tooltip />
                <Line type="monotone" dataKey="value" stroke="#4F46E5" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="bg-white rounded-xl border border-gray-200 p-4 shadow-sm">
            <h3 className="font-semibold text-gray-800 mb-3">Top Categories by Stock Value</h3>
            <div className="space-y-3 mt-2">
              {(byCategory ?? []).map((cat, i) => (
                <div key={cat.name} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-gray-700">{cat.name}</span>
                    <span className="font-semibold text-gray-800">{formatINR(cat.value)}</span>
                  </div>
                  <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                    <div className="h-full rounded-full" style={{ width: `${cat.percentage}%`, background: COLORS[i % COLORS.length] }}></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
