import { useState } from "react";
import { Download, Plus, Pencil, Trash2, Search } from "lucide-react";
import { LineChart, Line, PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import Layout from "@/components/Layout";
import StatCard from "@/components/StatCard";
import { formatINR } from "@/lib/format";
import {
  useGetCustomerStats, useGetCustomers, useGetCustomersBySegment,
  useGetCustomersTopByRevenue, useGetCustomersTrend, useGetCustomersByLocation,
  useDeleteCustomer, getGetCustomersQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";

const COLORS = ["#4F46E5", "#10B981", "#F59E0B", "#EF4444"];

function SegmentBadge({ segment }: { segment: string }) {
  const map: Record<string, string> = {
    "Premium": "bg-purple-100 text-purple-700",
    "VIP": "bg-amber-100 text-amber-700",
    "Regular": "bg-blue-100 text-blue-700",
    "New": "bg-emerald-100 text-emerald-700",
  };
  return <span className={`px-2 py-0.5 rounded-full text-[11px] font-medium ${map[segment] ?? "bg-gray-100 text-gray-600"}`}>{segment}</span>;
}

export default function Customers() {
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [segment, setSegment] = useState("");
  const queryClient = useQueryClient();

  const { data: stats } = useGetCustomerStats();
  const { data: customers } = useGetCustomers({ page, limit: 10, search: search || undefined, segment: segment || undefined });
  const { data: bySegment } = useGetCustomersBySegment();
  const { data: topByRevenue } = useGetCustomersTopByRevenue();
  const { data: trend } = useGetCustomersTrend();
  const { data: byLocation } = useGetCustomersByLocation();
  const deleteMutation = useDeleteCustomer({
    mutation: { onSuccess: () => queryClient.invalidateQueries({ queryKey: getGetCustomersQueryKey() }) },
  });

  return (
    <Layout>
      <div className="p-6 space-y-5">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold text-gray-900">Customers</h1>
            <p className="text-gray-500 text-sm">Manage and analyze your customer base</p>
          </div>
          <div className="flex gap-2">
            <button className="flex items-center gap-2 border border-gray-200 bg-white text-gray-700 text-sm px-3 py-2 rounded-lg hover:bg-gray-50">
              <Download className="w-4 h-4" /> Export
            </button>
            <button className="flex items-center gap-2 bg-blue-600 text-white text-sm px-4 py-2 rounded-lg hover:bg-blue-700 font-medium">
              <Plus className="w-4 h-4" /> Add Customer
            </button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-5 gap-4">
          <StatCard title="Total Customers" value={(stats?.totalCustomers ?? 1280).toLocaleString("en-IN")} change={stats?.totalCustomersChange ?? 8.4}
            icon={<span className="text-blue-600 font-bold text-sm">C</span>} iconBg="bg-blue-100" />
          <StatCard title="New Customers" value={(stats?.newCustomers ?? 86).toLocaleString("en-IN")} change={stats?.newCustomersChange ?? 15.8}
            icon={<span className="text-emerald-600 font-bold text-sm">N</span>} iconBg="bg-emerald-100" />
          <StatCard title="Total Orders" value={(stats?.totalOrders ?? 4200).toLocaleString("en-IN")} change={stats?.totalOrdersChange ?? 12.2}
            icon={<span className="text-purple-600 font-bold text-sm">O</span>} iconBg="bg-purple-100" />
          <StatCard title="Total Revenue" value={formatINR(stats?.totalRevenue ?? 1245000)} change={stats?.totalRevenueChange ?? 18.6}
            icon={<span className="text-orange-600 font-bold text-sm">₹</span>} iconBg="bg-orange-100" />
          <StatCard title="Avg Customer Value" value={formatINR(stats?.avgCustomerValue ?? 9726)}
            icon={<span className="text-teal-600 font-bold text-sm">A</span>} iconBg="bg-teal-100" />
        </div>

        {/* Filters */}
        <div className="bg-white rounded-xl border border-gray-200 p-4 shadow-sm">
          <div className="flex items-center gap-3 flex-wrap">
            <div className="relative flex-1 min-w-48">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input type="search" placeholder="Search by name, email or phone" value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" />
            </div>
            <select value={segment} onChange={(e) => setSegment(e.target.value)}
              className="px-3 py-2 text-sm border border-gray-200 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-blue-500">
              <option value="">All Segments</option>
              {["Premium", "VIP", "Regular", "New"].map((s) => <option key={s}>{s}</option>)}
            </select>
            <button className="bg-blue-600 text-white text-sm px-4 py-2 rounded-lg hover:bg-blue-700">Apply Filters</button>
          </div>
        </div>

        <div className="grid grid-cols-12 gap-4">
          {/* Customer Table */}
          <div className="col-span-8 bg-white rounded-xl border border-gray-200 shadow-sm">
            <div className="p-4 border-b border-gray-100">
              <h3 className="font-semibold text-gray-800">Customer List</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead className="bg-gray-50 border-b border-gray-100">
                  <tr>
                    {["Customer", "Email", "Phone", "Segment", "Total Orders", "Total Spent", "Join Date", "Actions"].map((h) => (
                      <th key={h} className="text-left px-4 py-3 font-medium text-gray-500">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-50">
                  {(customers?.data ?? []).map((c) => (
                    <tr key={c.id} className="hover:bg-gray-50" data-testid={`customer-${c.id}`}>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <div className="w-7 h-7 rounded-full bg-blue-100 flex items-center justify-center text-blue-700 font-bold text-[10px]">
                            {c.name.charAt(0)}
                          </div>
                          <span className="font-medium text-gray-800">{c.name}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-gray-600">{c.email}</td>
                      <td className="px-4 py-3 text-gray-600">{c.phone}</td>
                      <td className="px-4 py-3"><SegmentBadge segment={c.segment} /></td>
                      <td className="px-4 py-3 text-gray-600">{c.totalOrders}</td>
                      <td className="px-4 py-3 font-semibold text-gray-800">{formatINR(c.totalSpent)}</td>
                      <td className="px-4 py-3 text-gray-500">{c.joinDate}</td>
                      <td className="px-4 py-3">
                        <div className="flex gap-1.5">
                          <button className="p-1 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded"><Pencil className="w-3.5 h-3.5" /></button>
                          <button onClick={() => deleteMutation.mutate({ id: c.id })}
                            className="p-1 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded"><Trash2 className="w-3.5 h-3.5" /></button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="flex items-center justify-between px-4 py-3 border-t border-gray-100">
              <span className="text-xs text-gray-500">Page {page} of {Math.ceil((customers?.total ?? 0) / 10)}</span>
              <div className="flex gap-1">
                {[1, 2, 3, 4, 5].map((p) => (
                  <button key={p} onClick={() => setPage(p)}
                    className={`w-7 h-7 text-xs rounded ${page === p ? "bg-blue-600 text-white" : "text-gray-500 hover:bg-gray-100"}`}>{p}</button>
                ))}
              </div>
            </div>
          </div>

          {/* Right Panel */}
          <div className="col-span-4 space-y-4">
            {/* Segment Donut */}
            <div className="bg-white rounded-xl border border-gray-200 p-4 shadow-sm">
              <h3 className="font-semibold text-gray-800 mb-3 text-sm">Customer by Segment</h3>
              <div className="flex items-center gap-3">
                <ResponsiveContainer width={100} height={100}>
                  <PieChart>
                    <Pie data={bySegment ?? []} dataKey="value" cx="50%" cy="50%" innerRadius={25} outerRadius={45}>
                      {(bySegment ?? []).map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>
                <div className="flex-1 space-y-1.5">
                  {(bySegment ?? []).map((s, i) => (
                    <div key={s.name} className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-1.5">
                        <div className="w-2 h-2 rounded-full" style={{ background: COLORS[i % COLORS.length] }}></div>
                        <span className="text-gray-600">{s.name}</span>
                      </div>
                      <span className="text-gray-500">{s.percentage}%</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Top by Revenue */}
            <div className="bg-white rounded-xl border border-gray-200 p-4 shadow-sm">
              <h3 className="font-semibold text-gray-800 mb-3 text-sm">Top Customers by Revenue</h3>
              <div className="space-y-2.5">
                {(topByRevenue ?? []).map((c, i) => (
                  <div key={c.id} className="flex items-center gap-2 text-xs">
                    <span className="w-5 h-5 bg-blue-100 rounded-full flex items-center justify-center text-blue-700 font-bold">{i + 1}</span>
                    <div className="w-6 h-6 rounded-full bg-purple-100 flex items-center justify-center text-purple-700 font-bold text-[10px]">{c.name.charAt(0)}</div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-gray-800 truncate">{c.name}</p>
                      <SegmentBadge segment={c.segment} />
                    </div>
                    <span className="font-semibold text-gray-800 flex-shrink-0">{formatINR(c.revenue)}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Charts */}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white rounded-xl border border-gray-200 p-4 shadow-sm">
            <h3 className="font-semibold text-gray-800 mb-3">New Customers Trend</h3>
            <ResponsiveContainer width="100%" height={160}>
              <LineChart data={trend ?? []}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="label" tick={{ fontSize: 9 }} />
                <YAxis tick={{ fontSize: 9 }} />
                <Tooltip />
                <Line type="monotone" dataKey="value" stroke="#4F46E5" strokeWidth={2} dot={false} name="New Customers" />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="bg-white rounded-xl border border-gray-200 p-4 shadow-sm">
            <h3 className="font-semibold text-gray-800 mb-3">Customers by Location</h3>
            <ResponsiveContainer width="100%" height={160}>
              <BarChart data={byLocation ?? []} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis type="number" tick={{ fontSize: 9 }} />
                <YAxis type="category" dataKey="location" tick={{ fontSize: 9 }} width={80} />
                <Tooltip />
                <Bar dataKey="count" fill="#2563EB" radius={[0, 3, 3, 0]} name="Customers" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </Layout>
  );
}
