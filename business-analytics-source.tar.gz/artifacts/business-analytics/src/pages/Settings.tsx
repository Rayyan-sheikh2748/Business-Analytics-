import { useState } from "react";
import { Save, Shield, Bell, Globe, User, CreditCard, List, Trash2, RefreshCw, Database } from "lucide-react";
import Layout from "@/components/Layout";
import { useGetSettings, useUpdateSettings, getGetSettingsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";

const TABS = [
  { id: "general", label: "General", icon: Globe },
  { id: "profile", label: "Profile", icon: User },
  { id: "notifications", label: "Notifications", icon: Bell },
  { id: "security", label: "Security", icon: Shield },
  { id: "billing", label: "Billing", icon: CreditCard },
  { id: "audit", label: "Audit Logs", icon: List },
];

function Toggle({ checked, onChange }: { checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button onClick={() => onChange(!checked)}
      className={`relative inline-flex h-5 w-9 items-center rounded-full transition-colors ${checked ? "bg-blue-600" : "bg-gray-200"}`}>
      <span className={`inline-block h-4 w-4 rounded-full bg-white shadow transform transition-transform ${checked ? "translate-x-4" : "translate-x-0.5"}`} />
    </button>
  );
}

export default function Settings() {
  const [activeTab, setActiveTab] = useState("general");
  const [saved, setSaved] = useState(false);
  const queryClient = useQueryClient();

  const { data: settings } = useGetSettings();
  const updateMutation = useUpdateSettings({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetSettingsQueryKey() });
        setSaved(true);
        setTimeout(() => setSaved(false), 2000);
      },
    },
  });

  const [form, setForm] = useState({
    businessName: "",
    businessEmail: "",
    defaultTheme: "light",
    language: "en",
    timezone: "Asia/Kolkata",
    currency: "INR",
    dateFormat: "DD/MM/YYYY",
    timeFormat: "12h",
    enableAnalytics: true,
    autoRefresh: true,
    emailNotifications: true,
    darkMode: false,
    compactView: false,
  });

  const effectiveForm = settings ? {
    businessName: settings.businessName ?? form.businessName,
    businessEmail: settings.businessEmail ?? form.businessEmail,
    defaultTheme: settings.defaultTheme ?? form.defaultTheme,
    language: settings.language ?? form.language,
    timezone: settings.timezone ?? form.timezone,
    currency: settings.currency ?? form.currency,
    dateFormat: settings.dateFormat ?? form.dateFormat,
    timeFormat: settings.timeFormat ?? form.timeFormat,
    enableAnalytics: settings.enableAnalytics ?? form.enableAnalytics,
    autoRefresh: settings.autoRefresh ?? form.autoRefresh,
    emailNotifications: settings.emailNotifications ?? form.emailNotifications,
    darkMode: settings.darkMode ?? form.darkMode,
    compactView: settings.compactView ?? form.compactView,
  } : form;

  function update(key: string, value: string | boolean) {
    setForm((prev) => ({ ...prev, [key]: value }));
    updateMutation.mutate({ data: { [key]: value } });
  }

  return (
    <Layout>
      <div className="p-6 space-y-5">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold text-gray-900">Settings</h1>
            <p className="text-gray-500 text-sm">Manage your account and application preferences</p>
          </div>
          {saved && (
            <div className="bg-emerald-100 text-emerald-700 text-sm px-4 py-2 rounded-lg font-medium">
              Settings saved successfully
            </div>
          )}
        </div>

        {/* Tabs */}
        <div className="flex gap-1 bg-gray-100 p-1 rounded-xl w-fit">
          {TABS.map(({ id, label, icon: Icon }) => (
            <button key={id} onClick={() => setActiveTab(id)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm transition-colors ${
                activeTab === id ? "bg-white text-gray-800 font-medium shadow-sm" : "text-gray-500 hover:text-gray-700"
              }`}>
              <Icon className="w-3.5 h-3.5" />
              {label}
            </button>
          ))}
        </div>

        {activeTab === "general" && (
          <div className="grid grid-cols-12 gap-4">
            {/* General Settings */}
            <div className="col-span-8 space-y-4">
              <div className="bg-white rounded-xl border border-gray-200 p-5 shadow-sm">
                <h3 className="font-semibold text-gray-800 mb-4">General Settings</h3>
                <div className="grid grid-cols-2 gap-4">
                  {[
                    { key: "businessName", label: "Business Name", placeholder: "Your Business Name" },
                    { key: "businessEmail", label: "Business Email", placeholder: "email@business.com" },
                    { key: "defaultTheme", label: "Default Theme", type: "select", options: ["light", "dark", "system"] },
                    { key: "language", label: "Language", type: "select", options: ["en", "hi", "mr", "ta"] },
                    { key: "timezone", label: "Timezone", type: "select", options: ["Asia/Kolkata", "Asia/Mumbai", "Asia/Chennai"] },
                    { key: "currency", label: "Currency", type: "select", options: ["INR", "USD", "EUR"] },
                    { key: "dateFormat", label: "Date Format", type: "select", options: ["DD/MM/YYYY", "MM/DD/YYYY", "YYYY-MM-DD"] },
                    { key: "timeFormat", label: "Time Format", type: "select", options: ["12h", "24h"] },
                  ].map(({ key, label, placeholder, type, options }) => (
                    <div key={key}>
                      <label className="block text-xs font-medium text-gray-700 mb-1">{label}</label>
                      {type === "select" ? (
                        <select value={(effectiveForm as Record<string, string | boolean>)[key] as string}
                          onChange={(e) => update(key, e.target.value)}
                          className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-blue-500">
                          {options!.map((o) => <option key={o}>{o}</option>)}
                        </select>
                      ) : (
                        <input type="text" placeholder={placeholder}
                          value={(effectiveForm as Record<string, string | boolean>)[key] as string}
                          onChange={(e) => update(key, e.target.value)}
                          className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" />
                      )}
                    </div>
                  ))}
                </div>
                <button onClick={() => updateMutation.mutate({ data: effectiveForm })}
                  className="mt-5 flex items-center gap-2 bg-blue-600 text-white text-sm px-4 py-2 rounded-lg hover:bg-blue-700 font-medium">
                  <Save className="w-4 h-4" />
                  Save General Settings
                </button>
              </div>

              {/* System Preferences */}
              <div className="bg-white rounded-xl border border-gray-200 p-5 shadow-sm">
                <h3 className="font-semibold text-gray-800 mb-4">System Preferences</h3>
                <div className="space-y-4">
                  {[
                    { key: "enableAnalytics", label: "Enable Analytics", desc: "Track usage and performance metrics" },
                    { key: "autoRefresh", label: "Auto Refresh Dashboard", desc: "Automatically refresh data every 5 minutes" },
                    { key: "emailNotifications", label: "Email Notifications", desc: "Receive email alerts for important events" },
                    { key: "darkMode", label: "Dark Mode", desc: "Enable dark theme for the application" },
                    { key: "compactView", label: "Compact View", desc: "Show more data in a denser layout" },
                  ].map(({ key, label, desc }) => (
                    <div key={key} className="flex items-center justify-between py-2 border-b border-gray-50 last:border-0">
                      <div>
                        <p className="text-sm font-medium text-gray-800">{label}</p>
                        <p className="text-xs text-gray-500">{desc}</p>
                      </div>
                      <Toggle
                        checked={(effectiveForm as Record<string, string | boolean>)[key] as boolean}
                        onChange={(v) => update(key, v)}
                      />
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Right Panel */}
            <div className="col-span-4 space-y-4">
              <div className="bg-white rounded-xl border border-gray-200 p-4 shadow-sm">
                <h3 className="font-semibold text-gray-800 mb-3 text-sm">Account Information</h3>
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 rounded-full bg-blue-600 flex items-center justify-center text-white font-bold text-lg">A</div>
                  <div>
                    <p className="font-semibold text-gray-800">{effectiveForm.businessName || "Business Admin"}</p>
                    <p className="text-xs text-gray-500">{effectiveForm.businessEmail || "admin@business.com"}</p>
                  </div>
                </div>
                <div className="space-y-1 text-xs">
                  <div className="flex justify-between py-1"><span className="text-gray-500">Plan</span><span className="font-medium text-gray-700">Professional</span></div>
                  <div className="flex justify-between py-1"><span className="text-gray-500">Currency</span><span className="font-medium text-gray-700">{effectiveForm.currency}</span></div>
                  <div className="flex justify-between py-1"><span className="text-gray-500">Timezone</span><span className="font-medium text-gray-700">{effectiveForm.timezone}</span></div>
                </div>
              </div>

              <div className="bg-white rounded-xl border border-gray-200 p-4 shadow-sm">
                <div className="flex items-center gap-2 mb-3">
                  <Database className="w-4 h-4 text-blue-600" />
                  <h3 className="font-semibold text-gray-800 text-sm">Data & Backup</h3>
                </div>
                <div className="space-y-2">
                  {["Export All Data (CSV)", "Export All Data (JSON)", "Create Backup"].map((action) => (
                    <button key={action} className="w-full text-left text-xs text-gray-700 px-3 py-2 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                      {action}
                    </button>
                  ))}
                </div>
              </div>

              <div className="bg-white rounded-xl border border-gray-200 p-4 shadow-sm">
                <div className="flex items-center gap-2 mb-3">
                  <Shield className="w-4 h-4 text-emerald-600" />
                  <h3 className="font-semibold text-gray-800 text-sm">Security</h3>
                </div>
                <div className="space-y-2 text-xs">
                  <button className="w-full text-left text-gray-700 px-3 py-2 border border-gray-200 rounded-lg hover:bg-gray-50">Change Password</button>
                  <button className="w-full text-left text-gray-700 px-3 py-2 border border-gray-200 rounded-lg hover:bg-gray-50">Enable 2FA</button>
                  <button className="w-full text-left text-gray-700 px-3 py-2 border border-gray-200 rounded-lg hover:bg-gray-50">View Login Sessions</button>
                </div>
              </div>

              <div className="bg-white rounded-xl border border-red-200 p-4 shadow-sm">
                <h3 className="font-semibold text-red-700 text-sm mb-3">Danger Zone</h3>
                <div className="space-y-2">
                  <button className="w-full flex items-center gap-2 text-xs text-red-600 px-3 py-2 border border-red-200 rounded-lg hover:bg-red-50">
                    <RefreshCw className="w-3.5 h-3.5" /> Clear Cache
                  </button>
                  <button className="w-full flex items-center gap-2 text-xs text-red-600 px-3 py-2 border border-red-200 rounded-lg hover:bg-red-50">
                    <RefreshCw className="w-3.5 h-3.5" /> Reset All Settings
                  </button>
                  <button className="w-full flex items-center gap-2 text-xs text-red-700 px-3 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700">
                    <Trash2 className="w-3.5 h-3.5" /> Delete Account
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab !== "general" && (
          <div className="bg-white rounded-xl border border-gray-200 p-12 text-center">
            <p className="text-gray-500 text-sm">This section is under construction. Check back soon.</p>
          </div>
        )}
      </div>
    </Layout>
  );
}
