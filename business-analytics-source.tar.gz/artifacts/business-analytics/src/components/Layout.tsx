import { Link, useLocation } from "wouter";
import {
  LayoutDashboard, ShoppingCart, Package, TrendingUp, FileBarChart,
  Users, Settings, Bell, HelpCircle, LogOut, BarChart3, Plus, RefreshCw,
  Download, ChevronRight, Search, Sun
} from "lucide-react";

const navItems = [
  { icon: LayoutDashboard, label: "Dashboard", href: "/" },
  { icon: ShoppingCart, label: "Sales", href: "/sales" },
  { icon: Package, label: "Inventory", href: "/inventory" },
  { icon: TrendingUp, label: "Forecasting", href: "/forecasting" },
  { icon: FileBarChart, label: "Reports", href: "/reports" },
  { icon: Users, label: "Customers", href: "/customers" },
  { icon: Settings, label: "Settings", href: "/settings" },
];

export default function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();

  return (
    <div className="flex h-screen bg-gray-50 overflow-hidden">
      {/* Sidebar */}
      <aside className="w-[220px] flex-shrink-0 bg-[#0F172A] flex flex-col h-full overflow-y-auto">
        {/* Logo */}
        <div className="flex items-center gap-2.5 px-5 py-5 border-b border-[#1E293B]">
          <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center flex-shrink-0">
            <BarChart3 className="w-4 h-4 text-white" />
          </div>
          <div>
            <div className="text-white font-bold text-sm leading-tight">Business Analytics</div>
            <div className="text-gray-400 text-[10px]">Dashboard</div>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 px-3 py-4 space-y-0.5">
          {navItems.map(({ icon: Icon, label, href }) => {
            const isActive = href === "/" ? location === "/" : location.startsWith(href);
            return (
              <Link key={href} href={href}>
                <div data-testid={`nav-${label.toLowerCase()}`}
                  className={`flex items-center gap-3 px-3 py-2.5 rounded-lg cursor-pointer transition-colors text-sm ${
                    isActive
                      ? "bg-blue-600 text-white font-medium"
                      : "text-gray-400 hover:bg-[#1E293B] hover:text-white"
                  }`}>
                  <Icon className="w-4 h-4 flex-shrink-0" />
                  {label}
                </div>
              </Link>
            );
          })}
        </nav>

        {/* Quick Actions (Dashboard only) */}
        {location === "/" && (
          <div className="px-4 py-3 border-t border-[#1E293B]">
            <p className="text-gray-500 text-[10px] font-semibold uppercase tracking-wider mb-2">Quick Actions</p>
            {[
              { icon: Plus, label: "Add New Sale", href: "/sales" },
              { icon: Package, label: "Add New Product", href: "/inventory" },
              { icon: FileBarChart, label: "Generate Report", href: "/reports" },
              { icon: Download, label: "Backup Data", href: "/settings" },
            ].map(({ icon: Icon, label, href }) => (
              <Link key={label} href={href}>
                <div className="flex items-center gap-2 py-1.5 text-gray-400 hover:text-white cursor-pointer transition-colors text-xs">
                  <Icon className="w-3.5 h-3.5" />
                  {label}
                </div>
              </Link>
            ))}
          </div>
        )}

        {/* Bottom */}
        <div className="px-3 py-3 border-t border-[#1E293B] space-y-0.5">
          <div className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-gray-400 hover:bg-[#1E293B] hover:text-white cursor-pointer transition-colors text-sm">
            <Bell className="w-4 h-4" />
            <span>Alerts</span>
            <span className="ml-auto bg-red-500 text-white text-[10px] rounded-full w-4 h-4 flex items-center justify-center">8</span>
          </div>
          <div className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-gray-400 hover:bg-[#1E293B] hover:text-white cursor-pointer transition-colors text-sm">
            <HelpCircle className="w-4 h-4" />
            <span>Help & Support</span>
          </div>
          <div className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-gray-400 hover:bg-[#1E293B] hover:text-white cursor-pointer transition-colors text-sm">
            <LogOut className="w-4 h-4" />
            <span>Logout</span>
          </div>
        </div>
      </aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Topbar */}
        <header className="bg-white border-b border-gray-200 px-6 py-3 flex items-center gap-4 flex-shrink-0">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="search"
              placeholder="Search anything... Ctrl+K"
              className="w-full max-w-sm pl-9 pr-4 py-2 text-sm bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <button className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-lg transition-colors">
            <Sun className="w-4 h-4" />
          </button>
          <button className="relative p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-lg transition-colors">
            <Bell className="w-4 h-4" />
            <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
          </button>
          <div className="flex items-center gap-2 pl-3 border-l border-gray-200">
            <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white text-xs font-bold">A</div>
            <div>
              <div className="text-sm font-medium text-gray-800">Admin</div>
            </div>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto">
          {children}
        </main>
      </div>
    </div>
  );
}
